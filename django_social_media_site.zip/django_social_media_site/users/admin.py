from django.contrib import admin
from .models import UserImageExtension

admin.site.register(UserImageExtension)
